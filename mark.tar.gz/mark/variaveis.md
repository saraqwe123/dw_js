<h2>variáveis<h2>

## Declaração de variáveis 

## escopo

- sara
- pedro
- lara
- nati

- [] sara
- [x] sara

**sara**

`let`

```javascript
if (sara === x)
```